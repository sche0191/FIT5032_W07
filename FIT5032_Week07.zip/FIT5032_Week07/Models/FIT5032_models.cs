namespace FIT5032_Week07.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class FIT5032_models : DbContext
    {
        public FIT5032_models()
            : base("name=FIT5032_models")
        {
        }

        public virtual DbSet<students> students { get; set; }
        public virtual DbSet<Units> Units { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<students>()
                .HasMany(e => e.Units)
                .WithRequired(e => e.students)
                .HasForeignKey(e => e.StudentId)
                .WillCascadeOnDelete(false);
        }
    }
}
